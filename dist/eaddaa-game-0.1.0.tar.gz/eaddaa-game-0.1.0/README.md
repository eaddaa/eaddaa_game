<<<<<<< HEAD
# eaddaa Game

A simple text-based game project.

## How to Play

Run the following command in your terminal:

```bash
eaddaa-game
=======
# eaddaa_game
>>>>>>> 3a3dd9485816484f69e5c94fceb2b6ae480cf450
