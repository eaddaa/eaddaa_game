eaddaa Game is an exciting project with a focus on creating a number guessing game. The primary objective is to provide an engaging and enjoyable user experience through a simple yet entertaining game.

Installation
To install eaddaa_game on your local machine, follow these steps:

Clone the repository:

```
git clone https://github.com/eaddaa/eaddaa_game.git
```
Navigate to the project directory:
```
cd eaddaa_game

```
Install the required dependencies:

```

pip install -r requirements.txt
```
Usage
Run the game with the following command:
```
python3 main.py
```
can be found here
```
https://pypi.org/project/eaddaa-game/0.1.0/
```

Feel free to explore and enjoy the game!









